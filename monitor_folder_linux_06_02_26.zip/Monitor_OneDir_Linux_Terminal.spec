# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for MonitorApp - One Directory Build (Linux with Terminal)
Build with:
  pyinstaller --clean --noconfirm Monitor_OneDir_Linux_Terminal.spec

This creates a directory containing the executable and all dependencies,
with data files external in a 'data' folder and config.json for easy access.
Linux-specific configuration with terminal console always visible for debugging.
Terminal will remain open to show print statements and program output.
"""

from PyInstaller.utils.hooks import collect_submodules, collect_data_files, collect_dynamic_libs
import os

block_cipher = None

project_root = os.path.abspath('.')  # ensure root on sys.path for Analysis

app_name = 'monitor'
entry_script = 'monitor/gui/app.py'  # Direct app entry

# Collect all PySide6 modules & their data (Qt plugins) to avoid missing plugin errors
pyside_hidden = collect_submodules('PySide6')
qt_datas = collect_data_files('PySide6')  # includes translations, etc.
qt_binaries = collect_dynamic_libs('PySide6')  # Qt platform binaries

# Collect phonenumbers modules and data files
phonenumbers_datas = collect_data_files('phonenumbers')

# App specific data (read-only inside bundle)
# NOTE: config.json and data/ files are NOT included here - they stay external
app_datas = [
    ('monitor/gui/styles', 'monitor/gui/styles'),
    ('monitor/gui/icons', 'monitor/gui/icons'),
]

# NOTE: matplotlib is being auto-detected (likely via pandas' optional hooks) and
# causes a build-time ImportError (numpy.core.multiarray failed to import) in your
# current global Python install. If you do NOT use matplotlib at runtime, we
# explicitly exclude it to skip PyInstaller's hook-matplotlib execution.
# If you later add real matplotlib usage, remove it from 'excludes' and ensure
# numpy/matplotlib are properly installed in the active virtual environment.

a = Analysis(
    [entry_script],
    pathex=[project_root],
    binaries=qt_binaries,  # Include Qt binaries for Linux compatibility
    datas=app_datas + qt_datas + phonenumbers_datas,
    hiddenimports=pyside_hidden + [
        'monitor.legacy_code',
        'monitor.legacy_code.os_class',
        'monitor.legacy_code.server_class',
        'phonenumbers',
        'phonenumbers.geocoder',
        'phonenumbers.carrier',
        'phonenumbers.timezone',
        'phonenumbers.data',
        'phonenumbers.shortdata',
    ] + collect_submodules('phonenumbers'),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tests',       # exclude test package if discovered
        'pytest',
        'matplotlib',  # exclude problematic optional dependency
    ],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# One-directory build: executable and dependencies in separate files
# Terminal configuration for debugging and output visibility
exe = EXE(
    pyz,
    a.scripts,
    exclude_binaries=True,  # Keep binaries separate for one-dir build
    name=app_name,
    debug=True,             # Enable debug mode for more verbose output
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,              # Disable UPX for better Linux compatibility
    console=True,           # Enable console for debugging and print output
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # Note: Linux uses .png for icons, or you can omit this line if no icon is needed
    # icon='monitor/gui/icons/ecg-monitor.png',
)

# COLLECT section for one-directory builds
# This creates a directory with the executable and all dependencies in _internal
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name=app_name,
)

# Output structure after deployment on Linux:
# dist/monitor/
# ├── monitor             (main executable)
# ├── _internal/          (PyInstaller internal files and dependencies)
# │   ├── PySide6/        (Qt libraries and plugins)
# │   ├── phonenumbers/   (phone number data)
# │   └── ... (other dependencies)
# 
# External files (in same directory as dist/monitor/):
# ├── config.json         (configuration file - user editable)
# └── data/               (data directory - persistent storage)
#     ├── alerts.db
#     ├── contacts.db
#     ├── decision_engine_statuses.json
#     ├── devices.db
#     └── log_reader_state.json
#
# To run with terminal output visible:
# Method 1 (recommended): ./monitor
# Method 2: Open terminal and run: cd dist && ./monitor/monitor
# Method 3: Run from file manager with "Run in terminal" option
#
# Terminal will remain open showing all print statements and program output.
# For GUI applications, you'll see both the terminal output and the GUI window.
