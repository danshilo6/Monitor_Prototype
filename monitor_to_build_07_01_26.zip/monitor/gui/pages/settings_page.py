"""Settings page with multiple sub-pages"""

from PySide6.QtWidgets import QVBoxLayout, QLabel, QTabWidget
from PySide6.QtCore import Qt
from monitor.gui.pages.base_page import BasePage
from monitor.gui.pages.settings_sub_pages.general_settings import GeneralSettings
from monitor.gui.pages.settings_sub_pages.system_settings import SystemSettings  
from monitor.gui.pages.settings_sub_pages.devices_settings import DevicesSettings
from monitor.services.config_service import ConfigService

class SettingsPage(BasePage):
    """Settings page with tabbed sub-pages"""
    
    def __init__(self, config_service: ConfigService):
        self._general_settings = None
        self._system_settings = None
        self._devices_settings = None
        self.config_service = config_service  # Injected dependency
        super().__init__()
    
    def setup_ui(self):
        """Setup the settings page UI with tabs"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        
        # Page header
        header = QLabel("Settings")
        header.setObjectName("page-header")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)
        
        # Create tab widget
        self._tab_widget = QTabWidget()
        self._tab_widget.setObjectName("settings-tabs")
        
        # Create sub-pages
        self._general_settings = GeneralSettings(self.config_service)
        self._system_settings = SystemSettings(self.config_service)
        self._devices_settings = DevicesSettings(self.config_service)
        
        # Add tabs
        self._tab_widget.addTab(self._general_settings, "General")
        self._tab_widget.addTab(self._system_settings, "System")
        self._tab_widget.addTab(self._devices_settings, "Devices")
        
        layout.addWidget(self._tab_widget)
    
    def get_general_settings(self) -> GeneralSettings | None:
        """Get the general settings widget"""
        return self._general_settings
    
    def get_system_settings(self) -> SystemSettings | None:
        """Get the system settings widget"""
        return self._system_settings
    
    def get_devices_settings(self) -> DevicesSettings | None:
        """Get the devices settings widget"""
        return self._devices_settings
    
    def get_title(self) -> str:
        """Return the page title"""
        return "Application Settings"
    
    def get_description(self) -> str:
        """Return the page description"""
        return "Configure application preferences and advanced options"
    
    def cleanup(self):
        """Clean up resources when page is destroyed"""
        super().cleanup()  # Call base class cleanup
        
        # No specific cleanup needed for settings tabs as they are properly
        # managed by the QTabWidget, but we could add any future cleanup here
        pass