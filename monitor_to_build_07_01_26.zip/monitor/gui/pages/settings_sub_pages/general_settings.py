"""General settings tab"""

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QWidget, QLineEdit, 
                               QPushButton, QFileDialog, QLabel, QMessageBox)
from PySide6.QtCore import Qt, Signal
from ...widgets.location_name_dialog import LocationNameDialog
from monitor.core.os_manager import OSManager

class GeneralSettings(QWidget):
    """General settings tab widget"""
    
    # Signal emitted when location name changes
    location_changed = Signal(str)
    
    def __init__(self, config_service):
        super().__init__()
        self._config = config_service
        self._os_manager = OSManager(config_service)  # Initialize OSManager
        self._setup_ui()
        self._load_from_config()
    
    def _setup_ui(self):
        """Setup the general settings UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Location Name Section
        self._create_location_name_section(layout)
        
        # File Path Section  
        self._create_filepath_section(layout)
        
        # Add stretch to push content to top
        layout.addStretch()
    
    def _create_location_name_section(self, layout: QVBoxLayout):
        """Create location name input section"""
        # Title label
        location_title = QLabel("Location Name:")
        location_title.setObjectName("settings-label")
        layout.addWidget(location_title)
        
        # Create horizontal layout for location name display and edit button
        location_name_layout = QHBoxLayout()
        
        # Location name display (read-only)
        self._location_name_display = QLineEdit()
        self._location_name_display.setObjectName("settings-display")
        self._location_name_display.setReadOnly(True)
        self._location_name_display.setPlaceholderText("Enter location name...")  # Placeholder text
        
        # Edit button
        self._edit_location_name_btn = QPushButton("Edit")
        self._edit_location_name_btn.setObjectName("settings-button")
        self._edit_location_name_btn.clicked.connect(self._edit_location_name)
        
        # Add to layout
        location_name_layout.addWidget(self._location_name_display)
        location_name_layout.addWidget(self._edit_location_name_btn)
        
        # Add horizontal layout to main layout
        layout.addLayout(location_name_layout)
    
    def _create_filepath_section(self, layout: QVBoxLayout):
        """Create file path selection section"""
        # Title label
        filepath_title = QLabel("Ein-Tzofia Path:")
        filepath_title.setObjectName("settings-label")
        layout.addWidget(filepath_title)
        
        # Create horizontal layout for path display and choose button
        filepath_layout = QHBoxLayout()
        
        # File path display (read-only)
        self._filepath_display = QLineEdit()
        self._filepath_display.setObjectName("settings-display")
        self._filepath_display.setReadOnly(True)
        self._filepath_display.setPlaceholderText("No file selected...")
        
        # Choose file button
        self._choose_file_btn = QPushButton("Choose File")
        self._choose_file_btn.setObjectName("settings-button")
        self._choose_file_btn.clicked.connect(self._choose_file)
        
        # Add to layout
        filepath_layout.addWidget(self._filepath_display)
        filepath_layout.addWidget(self._choose_file_btn)
        
        # Add horizontal layout to main layout
        layout.addLayout(filepath_layout)
        
        # Open/Restart Ein Tzofia button
        self._open_ein_tzofia_btn = QPushButton("Open/Reopen Ein Tzofia")
        self._open_ein_tzofia_btn.setObjectName("open-button")
        self._open_ein_tzofia_btn.clicked.connect(self._open_ein_tzofia)
        self._open_ein_tzofia_btn.setEnabled(True)  # Always enabled for manual use
        self._open_ein_tzofia_btn.setToolTip("Open EinTzofia manually")
        layout.addWidget(self._open_ein_tzofia_btn)
    
    def _edit_location_name(self):
        """Open dialog to edit location name"""
        current_location_name = self._location_name_display.text()
        accepted, new_location_name = LocationNameDialog.edit_location_name(current_location_name, self)
        if accepted and new_location_name:
            self._location_name_display.setText(new_location_name)
            self._config.set("general", "location_name", new_location_name)
            
            # Emit signal to notify other components of the location name change
            self.location_changed.emit(new_location_name)

    
    def _choose_file(self):
        """Open file dialog to choose monitored program"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Program to Monitor",
            "",
            "Executable Files (*.exe);;All Files (*)"
        )
        if file_path:
            self._filepath_display.setText(file_path)
            self._config.set("general", "eintzofia_path", file_path)

    def _load_from_config(self):
        """Load settings from config on startup"""
        # Block signals to prevent saving during load
        self._location_name_display.blockSignals(True)
        self._filepath_display.blockSignals(True)
        
        # Load values
        location = self._config.get("general", "location_name", "")
        self._location_name_display.setText(location)
        program_path = self._config.get("general", "eintzofia_path", "")
        self._filepath_display.setText(program_path)
        
        # Re-enable signals
        self._location_name_display.blockSignals(False)
        self._filepath_display.blockSignals(False)
    
    def get_location_name(self) -> str:
        """Get the current location name"""
        return self._location_name_display.text()
    
    def get_monitor_program_path(self) -> str:
        """Get the current monitor program path"""
        return self._filepath_display.text()
    
    def set_location_name(self, name: str):
        """Set the location name"""
        self._location_name_display.setText(name)
    
    def set_monitor_program_path(self, path: str):
        """Set the monitor program path"""
        self._filepath_display.setText(path)
    
    def _open_ein_tzofia(self):
        """Open Ein Tzofia using OSManager"""
        try:
            print("Opening Ein Tzofia...")
            
            # Get EinTzofia path from config
            eintzofia_path = self._config.get("general", "eintzofia_path", "")
            
            if not eintzofia_path:
                QMessageBox.warning(
                    self, 
                    "EinTzofia Path Not Found", 
                    "EinTzofia path is not configured.\n\n"
                    "Please set the EinTzofia path first by clicking 'Choose File'."
                )
                return
            
            # Use OSManager to open the file
            success = self._os_manager.open_file(eintzofia_path)
            
            if success:
                print(f"Successfully opened EinTzofia: {eintzofia_path}")
            else:
                print(f"Failed to open EinTzofia: {eintzofia_path}")
                QMessageBox.warning(
                    self,
                    "Failed to Open",
                    f"Failed to open EinTzofia.\n\nPath: {eintzofia_path}\n\n"
                    "Please check if the file exists and is executable."
                )
                
        except Exception as e:
            print(f"Error opening EinTzofia: {e}")
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while opening EinTzofia:\n\n{str(e)}"
            )
